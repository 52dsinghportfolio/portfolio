


const links document.querySelectorAll(".alternate-style"),
totalLinks links.length; 

function setActiveStyle(coLor)
{
	for(let i=0; i totalLinks; i++)
	{
		(color== links[i].getAttribute("title"))
		{
			links[i].removeAttribute("disabled"); 
		} 
	}
	else
	{
		links[i].setAttribute("disabled","true");
	} 
}




 
 




